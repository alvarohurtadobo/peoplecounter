# peoplecounter
People counter algorithm for surveillance and bus entrance applications

Works in Linux computer with python 3.7.3 and OpenCV 4.1 installed.

To setup your linux computer for dlib, run the next commands:

```
sudo apt-get update
sudo apt-get install build-essential cmake -y
sudo apt-get install libopenblas-dev liblapack-dev -y
sudo apt-get install libx11-dev libgtk-3-dev -y
sudo apt-get install python python-dev python-pip -y
sudo apt-get install python3 python3-dev python3-pip -y
```

Then install using pip:

```
pip install -r requirements.txt
```

Further information at:

www.deepmicrosystems.com
info@deepmicrosystems.com


