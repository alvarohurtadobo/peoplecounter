class TrackableObject:
	def __init__(self, objectID, centroid):
		# store the object ID, then initialize a list of centroids
		self.objectID = objectID
		self.centroids = [centroid]

		self.counted = False